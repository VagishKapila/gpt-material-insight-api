from flask import Flask, render_template, request, send_from_directory, jsonify
from reportlab.pdfgen import canvas
import io
import os
import datetime

app = Flask(__name__)

# Ensure PDF output directory exists
OUTPUT_DIR = "generated_pdfs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

@app.route("/")
def form():
    return render_template("form.html")

@app.route("/generate", methods=["POST"])
def generate():
    try:
        data = request.form
        project_id = data.get("project_id", "UnknownProject")
        work_summary = data.get("work_summary", "N/A")
        materials = data.get("materials", "N/A")

        filename = f"{project_id}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = os.path.join(OUTPUT_DIR, filename)

        # Create PDF
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer)
        c.drawString(100, 750, f"Project ID: {project_id}")
        c.drawString(100, 730, f"Work Summary: {work_summary}")
        c.drawString(100, 710, f"Materials Used: {materials}")
        c.save()

        buffer.seek(0)
        with open(filepath, "wb") as f:
            f.write(buffer.read())

        return jsonify({
            "message": "✅ PDF created successfully.",
            "preview_url": f"/preview/{filename}",
            "download_url": f"/download/{filename}"
        })

    except Exception as e:
        return f"❌ Error: {str(e)}", 500

@app.route("/preview/<filename>")
def preview(filename):
    return send_from_directory(OUTPUT_DIR, filename)

@app.route("/download/<filename>")
def download(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)